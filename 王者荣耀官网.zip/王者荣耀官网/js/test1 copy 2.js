function printMenu() {
  console.log("1. 登录");
  console.log("2. 注册");
}