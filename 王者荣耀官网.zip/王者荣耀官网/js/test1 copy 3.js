// 获取页面中类样式为header的元素，获取到的是一个dom对象，将它保存到abc中
var abc = document.querySelector(".header");
// console.log(abc.className);
var person = {
  name: "成哥",
};
person.name = "邓哥";
console.log(person);
