var div = document.querySelector(".footer .footer-links");
div.style.color = "red";
div.style.marginTop = "1000px";