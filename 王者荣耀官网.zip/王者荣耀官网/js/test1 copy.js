
var a = 1 + 1 + "3";
console.log(a);
