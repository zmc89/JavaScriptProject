// 获取页面中类样式为header的元素，获取到的是一个dom对象，将它保存到abc中
var abc = document.querySelector(".header");
// abc.className = "dfasdfasfsafd";
// console.log(abc.tagName);
// console.log(abc.children);

// 将abc元素的第一个子元素的类名改为123
// abc.children[0].className = "123";

